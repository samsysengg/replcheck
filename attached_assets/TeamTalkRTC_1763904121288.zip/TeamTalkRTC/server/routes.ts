import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { sessionMiddleware } from "./app";
import { z } from "zod";
import { insertUserSchema, insertMessageSchema, type OnlineUser, type CallSignal, type TypingIndicator } from "@shared/schema";

const connectedUsers = new Map<string, { socketId: string; userId: string }>();

function requireAuth(req: Request, res: any, next: any) {
  const userId = (req.session as any)?.userId;
  if (!userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: (origin, callback) => {
        const deploymentOriginReplit = process.env.REPL_SLUG 
          ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.replit.dev`
          : null;
        const deploymentOriginReplCo = process.env.REPL_SLUG 
          ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
          : null;
        
        const allowedOrigins = [
          "http://localhost:5000",
          "https://localhost:5000",
          deploymentOriginReplit,
          deploymentOriginReplCo,
        ].filter(Boolean);
        
        if (origin && allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          console.log(`Rejected Socket.IO connection from origin: ${origin || 'null'}`);
          callback(new Error("Not allowed by CORS"));
        }
      },
      methods: ["GET", "POST"],
      credentials: true,
    },
  });

  io.engine.use(sessionMiddleware);

  // Auth endpoints
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      if (!data.displayName || data.displayName.trim().length === 0) {
        return res.status(400).json({ message: "Display name is required" });
      }
      
      const existingUser = await storage.getUserByUsername(data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(data.password, 10);
      const user = await storage.createUser({ ...data, password: hashedPassword });
      await storage.updateUserStatus(user.id, "online");
      (req.session as any).userId = user.id;
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      await storage.updateUserStatus(user.id, "online");
      (req.session as any).userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Login failed" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out" });
    });
  });

  // Message endpoints
  app.get("/api/messages/:roomId", requireAuth, async (req, res) => {
    try {
      const roomId = req.params.roomId;
      const userId = (req.session as any).userId;
      
      let chatRoom = await storage.getChatRoomByRoomId(roomId);
      if (!chatRoom) {
        const participants = roomId.split("---");
        if (participants.length === 2) {
          if (!participants.includes(userId)) {
            return res.status(403).json({ message: "Access denied" });
          }
          chatRoom = await storage.createChatRoom({
            participants,
            isGroup: false,
            name: null,
          }, roomId);
        } else {
          return res.status(400).json({ message: "Invalid room ID" });
        }
      } else {
        if (!chatRoom.participants.includes(userId)) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      const messages = await storage.getMessagesByRoom(roomId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Socket.io for real-time communication
  io.on("connection", (socket) => {
    const req = socket.request as Request;
    const userId = (req.session as any)?.userId;
    
    if (userId) {
      connectedUsers.set(socket.id, { socketId: socket.id, userId });
      
      storage.updateUserStatus(userId, "online");
      
      broadcastOnlineUsers(io);
      
      socket.on("disconnect", async () => {
        connectedUsers.delete(socket.id);
        await storage.updateUserStatus(userId, "offline");
        broadcastOnlineUsers(io);
      });

      socket.on("join-room", async (roomId: string) => {
        const chatRoom = await storage.getChatRoomByRoomId(roomId);
        if (chatRoom && chatRoom.participants.includes(userId)) {
          socket.join(roomId);
        }
      });

      socket.on("leave-room", (roomId: string) => {
        socket.leave(roomId);
      });

      socket.on("message", async (data: { roomId: string; content: string }) => {
        try {
          let chatRoom = await storage.getChatRoomByRoomId(data.roomId);
          if (!chatRoom) {
            const participants = data.roomId.split("---");
            if (!participants.includes(userId)) {
              return;
            }
            chatRoom = await storage.createChatRoom({
              participants,
              isGroup: false,
              name: null,
            }, data.roomId);
          } else {
            if (!chatRoom.participants.includes(userId)) {
              return;
            }
          }

          const message = await storage.createMessage({
            roomId: data.roomId,
            senderId: userId,
            content: data.content,
          });

          await storage.updateChatRoomLastMessage(data.roomId, data.content);

          const messageWithISOTimestamp = {
            ...message,
            timestamp: message.timestamp.toISOString(),
          };

          io.to(data.roomId).emit("message", messageWithISOTimestamp);
        } catch (error) {
          console.error("Message error:", error);
        }
      });

      socket.on("typing", async (data: { roomId: string; isTyping: boolean }) => {
        const chatRoom = await storage.getChatRoomByRoomId(data.roomId);
        if (chatRoom && chatRoom.participants.includes(userId)) {
          const user = await storage.getUser(userId);
          if (user) {
            socket.to(data.roomId).emit("typing", {
              userId,
              userName: user.displayName,
              isTyping: data.isTyping,
            });
          }
        }
      });

      socket.on("call-signal", async (signal: CallSignal) => {
        if (signal.to) {
          const roomId = [userId, signal.to].sort().join("---");
          const chatRoom = await storage.getChatRoomByRoomId(roomId);
          if (chatRoom && chatRoom.participants.includes(userId)) {
            const targetUser = Array.from(connectedUsers.values()).find(
              (u) => u.userId === signal.to
            );
            if (targetUser) {
              io.to(targetUser.socketId).emit("call-signal", signal);
            }
          }
        }
      });
    }
  });

  async function broadcastOnlineUsers(io: SocketIOServer) {
    const userIds = Array.from(new Set(Array.from(connectedUsers.values()).map((u) => u.userId)));
    const users = await Promise.all(userIds.map((id) => storage.getUser(id)));
    const onlineUsers: OnlineUser[] = users
      .filter((u): u is NonNullable<typeof u> => u !== undefined)
      .map((u) => ({
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        status: u.status,
        avatarColor: u.avatarColor,
      }));
    
    io.emit("users-online", onlineUsers);
  }

  return httpServer;
}
