import {
  type User,
  type InsertUser,
  type Message,
  type InsertMessage,
  type ChatRoom,
  type InsertChatRoom,
  type UserStatus,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: string, status: UserStatus): Promise<void>;
  getAllUsers(): Promise<User[]>;

  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByRoom(roomId: string): Promise<Message[]>;
  markMessageAsRead(id: string): Promise<void>;

  // ChatRoom operations
  createChatRoom(room: InsertChatRoom, id?: string): Promise<ChatRoom>;
  getChatRoom(id: string): Promise<ChatRoom | undefined>;
  getChatRoomByRoomId(roomId: string): Promise<ChatRoom | undefined>;
  getChatRoomByParticipants(participants: string[]): Promise<ChatRoom | undefined>;
  updateChatRoomLastMessage(roomId: string, message: string): Promise<void>;
  getUserChatRooms(userId: string): Promise<ChatRoom[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private messages: Map<string, Message>;
  private chatRooms: Map<string, ChatRoom>;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.chatRooms = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      status: "offline",
      avatarColor: `#${Math.floor(Math.random() * 16777215).toString(16)}`,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStatus(id: string, status: UserStatus): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      this.users.set(id, { ...user, status });
    }
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date(),
      read: false,
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesByRoom(roomId: string): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter((msg) => msg.roomId === roomId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    return messages.map(msg => ({
      ...msg,
      timestamp: msg.timestamp as any,
    }));
  }

  async markMessageAsRead(id: string): Promise<void> {
    const message = this.messages.get(id);
    if (message) {
      this.messages.set(id, { ...message, read: true });
    }
  }

  async createChatRoom(insertRoom: InsertChatRoom, id?: string): Promise<ChatRoom> {
    const roomId = id || randomUUID();
    const room: ChatRoom = {
      ...insertRoom,
      id: roomId,
      lastMessage: null,
      lastMessageTime: null,
    };
    this.chatRooms.set(roomId, room);
    return room;
  }

  async getChatRoom(id: string): Promise<ChatRoom | undefined> {
    return this.chatRooms.get(id);
  }

  async getChatRoomByRoomId(roomId: string): Promise<ChatRoom | undefined> {
    const participants = roomId.split("---");
    return this.getChatRoomByParticipants(participants);
  }

  async getChatRoomByParticipants(participants: string[]): Promise<ChatRoom | undefined> {
    const sortedParticipants = [...participants].sort();
    return Array.from(this.chatRooms.values()).find((room) => {
      const sortedRoomParticipants = [...room.participants].sort();
      return (
        sortedParticipants.length === sortedRoomParticipants.length &&
        sortedParticipants.every((p, i) => p === sortedRoomParticipants[i])
      );
    });
  }

  async updateChatRoomLastMessage(roomId: string, message: string): Promise<void> {
    const room = this.chatRooms.get(roomId);
    if (room) {
      this.chatRooms.set(roomId, {
        ...room,
        lastMessage: message,
        lastMessageTime: new Date(),
      });
    }
  }

  async getUserChatRooms(userId: string): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values())
      .filter((room) => room.participants.includes(userId))
      .sort((a, b) => {
        if (!a.lastMessageTime) return 1;
        if (!b.lastMessageTime) return -1;
        return b.lastMessageTime.getTime() - a.lastMessageTime.getTime();
      });
  }
}

export const storage = new MemStorage();
