import { useEffect, useRef } from "react";
import { UserAvatar } from "@/components/user-avatar";
import { Badge } from "@/components/ui/badge";
import { MicOff, Video as VideoIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface Participant {
  id: string;
  name: string;
  avatarColor: string;
  stream?: MediaStream;
  isMuted?: boolean;
  isVideoOff?: boolean;
}

interface VideoGridProps {
  participants: Participant[];
  localStream?: MediaStream;
  layout?: "grid" | "speaker";
}

export function VideoGrid({ participants, localStream, layout = "grid" }: VideoGridProps) {
  return (
    <div className="w-full h-full p-4">
      <div
        className={cn(
          "grid gap-4 h-full",
          layout === "grid" && participants.length <= 1 && "grid-cols-1",
          layout === "grid" && participants.length === 2 && "grid-cols-1 md:grid-cols-2",
          layout === "grid" && participants.length <= 4 && participants.length > 2 && "grid-cols-2",
          layout === "grid" && participants.length > 4 && "grid-cols-2 md:grid-cols-3 xl:grid-cols-4"
        )}
      >
        {participants.map((participant) => (
          <VideoTile key={participant.id} participant={participant} />
        ))}
      </div>
    </div>
  );
}

function VideoTile({ participant }: { participant: Participant }) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  return (
    <div className="relative aspect-video bg-card rounded-lg overflow-hidden" data-testid={`video-tile-${participant.id}`}>
      {participant.stream && !participant.isVideoOff ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={participant.id === "local"}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-muted">
          <UserAvatar
            displayName={participant.name}
            avatarColor={participant.avatarColor}
            size="xl"
          />
        </div>
      )}

      <div className="absolute bottom-3 left-3 flex items-center gap-2">
        <Badge variant="secondary" className="backdrop-blur-sm bg-black/50 text-white border-0">
          {participant.name}
        </Badge>
        {participant.isMuted && (
          <div className="w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
            <MicOff className="w-4 h-4 text-white" />
          </div>
        )}
      </div>

      {participant.isVideoOff && (
        <div className="absolute top-3 right-3">
          <div className="w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
            <VideoIcon className="w-4 h-4 text-white" />
          </div>
        </div>
      )}
    </div>
  );
}
