import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/auth-context";
import { useSocket } from "@/lib/socket-context";
import { useQuery } from "@tanstack/react-query";
import { UserAvatar } from "@/components/user-avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Video, Phone, Send, Paperclip, Smile } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import type { Message, OnlineUser } from "@shared/schema";

interface ChatInterfaceProps {
  selectedUser: OnlineUser;
  onStartCall: (type: "video" | "audio") => void;
}

export function ChatInterface({ selectedUser, onStartCall }: ChatInterfaceProps) {
  const { user } = useAuth();
  const { socket, sendMessage, joinRoom, setTyping } = useSocket();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [typingUser, setTypingUser] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const roomId = [user?.id, selectedUser.id].sort().join("---");

  const { data: messageHistory, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages", roomId],
    enabled: !!roomId,
  });

  useEffect(() => {
    if (messageHistory) {
      setMessages(messageHistory);
    }
  }, [messageHistory]);

  useEffect(() => {
    if (socket && roomId) {
      joinRoom(roomId);

      socket.on("message", (msg: Message) => {
        setMessages((prev) => [...prev, msg]);
      });

      socket.on("typing", (data: { userId: string; userName: string; isTyping: boolean }) => {
        if (data.userId !== user?.id) {
          setTypingUser(data.isTyping ? data.userName : null);
        }
      });

      return () => {
        socket.off("message");
        socket.off("typing");
      };
    }
  }, [socket, roomId, user?.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim() && roomId) {
      sendMessage(roomId, message.trim());
      setMessage("");
      setTyping(roomId, false);
    }
  };

  const handleTyping = (value: string) => {
    setMessage(value);

    if (!isTyping && value.length > 0) {
      setIsTyping(true);
      setTyping(roomId, true);
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      setTyping(roomId, false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-4 px-6 py-4 border-b border-border">
        <UserAvatar
          displayName={selectedUser.displayName}
          avatarColor={selectedUser.avatarColor}
          status={selectedUser.status}
          size="md"
          showStatus
        />
        <div className="flex-1 min-w-0">
          <h2 className="text-lg font-semibold text-foreground truncate">{selectedUser.displayName}</h2>
          <p className="text-xs text-muted-foreground">
            {selectedUser.status === "online" ? "Active now" : "Offline"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onStartCall("audio")}
            data-testid="button-start-audio-call"
          >
            <Phone className="w-5 h-5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onStartCall("video")}
            data-testid="button-start-video-call"
          >
            <Video className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1 px-6 py-4">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-3">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-16 w-full max-w-md" />
                </div>
              </div>
            ))}
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <UserAvatar
                displayName={selectedUser.displayName}
                avatarColor={selectedUser.avatarColor}
                size="md"
              />
            </div>
            <h3 className="text-lg font-semibold mb-2">Start a conversation</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              Send a message to {selectedUser.displayName} or start a video call
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, index) => {
              const isOwn = msg.senderId === user?.id;
              const showAvatar = !isOwn && (index === 0 || messages[index - 1].senderId !== msg.senderId);

              return (
                <div
                  key={msg.id}
                  className={cn("flex gap-3", isOwn && "flex-row-reverse")}
                  data-testid={`message-${msg.id}`}
                >
                  <div className={cn("w-8", !showAvatar && "invisible")}>
                    {!isOwn && (
                      <UserAvatar
                        displayName={selectedUser.displayName}
                        avatarColor={selectedUser.avatarColor}
                        size="sm"
                      />
                    )}
                  </div>
                  <div className={cn("flex flex-col gap-1 max-w-2xl", isOwn && "items-end")}>
                    <div
                      className={cn(
                        "rounded-lg px-4 py-2",
                        isOwn ? "bg-primary text-primary-foreground" : "bg-muted"
                      )}
                    >
                      <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(msg.timestamp), "p")}
                    </span>
                  </div>
                </div>
              );
            })}
            <div ref={scrollRef} />
          </div>
        )}
        {typingUser && (
          <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
            <span className="flex gap-1">
              <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
            </span>
            <span>{typingUser} is typing...</span>
          </div>
        )}
      </ScrollArea>

      <div className="p-4 border-t border-border">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Textarea
              placeholder="Type a message..."
              value={message}
              onChange={(e) => handleTyping(e.target.value)}
              onKeyPress={handleKeyPress}
              className="resize-none min-h-[44px] max-h-32 pr-10"
              rows={1}
              data-testid="input-message"
            />
            <Button
              size="icon"
              variant="ghost"
              className="absolute right-2 top-2"
              data-testid="button-emoji"
            >
              <Smile className="w-4 h-4" />
            </Button>
          </div>
          <Button
            size="icon"
            variant="ghost"
            data-testid="button-attach"
          >
            <Paperclip className="w-5 h-5" />
          </Button>
          <Button
            size="icon"
            onClick={handleSendMessage}
            disabled={!message.trim()}
            data-testid="button-send-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
