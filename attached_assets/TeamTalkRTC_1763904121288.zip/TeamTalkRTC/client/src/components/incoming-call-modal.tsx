import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/user-avatar";
import { Phone, PhoneOff, Video } from "lucide-react";

interface IncomingCallModalProps {
  open: boolean;
  callerName: string;
  callerAvatar: string;
  callType: "video" | "audio";
  onAccept: () => void;
  onDecline: () => void;
}

export function IncomingCallModal({
  open,
  callerName,
  callerAvatar,
  callType,
  onAccept,
  onDecline,
}: IncomingCallModalProps) {
  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-incoming-call">
        <DialogHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="relative">
              <UserAvatar displayName={callerName} avatarColor={callerAvatar} size="xl" />
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center animate-pulse">
                  {callType === "video" ? (
                    <Video className="w-5 h-5 text-primary-foreground" />
                  ) : (
                    <Phone className="w-5 h-5 text-primary-foreground" />
                  )}
                </div>
              </div>
            </div>
          </div>
          <DialogTitle className="text-2xl">{callerName}</DialogTitle>
          <DialogDescription className="text-base">
            Incoming {callType} call
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="sm:justify-center gap-4 mt-6">
          <Button
            variant="destructive"
            size="lg"
            onClick={onDecline}
            className="w-full sm:w-auto min-w-32 rounded-full"
            data-testid="button-decline-call"
          >
            <PhoneOff className="w-5 h-5 mr-2" />
            Decline
          </Button>
          <Button
            size="lg"
            onClick={onAccept}
            className="w-full sm:w-auto min-w-32 rounded-full bg-green-600 hover:bg-green-700"
            data-testid="button-accept-call"
          >
            <Phone className="w-5 h-5 mr-2" />
            Accept
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
