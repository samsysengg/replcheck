import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { UserStatus } from "@shared/schema";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  displayName: string;
  avatarColor?: string;
  status?: UserStatus;
  size?: "sm" | "md" | "lg" | "xl";
  showStatus?: boolean;
}

const sizeClasses = {
  sm: "w-8 h-8 text-xs",
  md: "w-10 h-10 text-sm",
  lg: "w-16 h-16 text-lg",
  xl: "w-20 h-20 text-xl",
};

const statusSizeClasses = {
  sm: "w-2 h-2",
  md: "w-3 h-3",
  lg: "w-4 h-4",
  xl: "w-5 h-5",
};

const statusColors = {
  online: "bg-status-online",
  away: "bg-status-away",
  busy: "bg-status-busy",
  offline: "bg-status-offline",
};

export function UserAvatar({ displayName, avatarColor = "#3b82f6", status = "offline", size = "md", showStatus = false }: UserAvatarProps) {
  const initials = (displayName || "")
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2) || "?";

  return (
    <div className="relative inline-block">
      <Avatar className={cn(sizeClasses[size])} style={{ backgroundColor: avatarColor }}>
        <AvatarFallback className="bg-transparent text-white font-medium">
          {initials}
        </AvatarFallback>
      </Avatar>
      {showStatus && (
        <span
          className={cn(
            "absolute -bottom-0.5 -right-0.5 rounded-full border-2 border-background",
            statusSizeClasses[size],
            statusColors[status]
          )}
        />
      )}
    </div>
  );
}
