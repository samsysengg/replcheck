import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { UserAvatar } from "@/components/user-avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/lib/theme-provider";
import {
  MessageSquare,
  Users,
  Phone,
  Settings,
  Search,
  Plus,
  LogOut,
  Moon,
  Sun,
  Video,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { OnlineUser } from "@shared/schema";

interface SidebarNavProps {
  onlineUsers: OnlineUser[];
  onSelectUser: (user: OnlineUser) => void;
  selectedUserId?: string;
  activeTab: "chat" | "calls";
  onTabChange: (tab: "chat" | "calls") => void;
}

export function SidebarNav({ onlineUsers, onSelectUser, selectedUserId, activeTab, onTabChange }: SidebarNavProps) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredUsers = onlineUsers.filter(
    (u) =>
      u.id !== user?.id &&
      (u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.username.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (!user) return null;

  return (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border">
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3 mb-4">
          <UserAvatar
            displayName={user.displayName}
            avatarColor={user.avatarColor}
            status={user.status}
            size="md"
            showStatus
          />
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm text-sidebar-foreground truncate">{user.displayName}</h3>
            <p className="text-xs text-muted-foreground truncate">@{user.username}</p>
          </div>
          <Button
            size="icon"
            variant="ghost"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
            className="shrink-0"
          >
            {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </Button>
        </div>

        <div className="flex gap-1">
          <Button
            variant={activeTab === "chat" ? "default" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={() => onTabChange("chat")}
            data-testid="button-tab-chat"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat
          </Button>
          <Button
            variant={activeTab === "calls" ? "default" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={() => onTabChange("calls")}
            data-testid="button-tab-calls"
          >
            <Phone className="w-4 h-4 mr-2" />
            Calls
          </Button>
        </div>
      </div>

      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-contacts"
          />
        </div>
      </div>

      <ScrollArea className="flex-1 px-2">
        <div className="space-y-1 pb-4">
          <div className="px-3 py-2">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Online ({filteredUsers.length})
            </h4>
          </div>
          {filteredUsers.length === 0 ? (
            <div className="px-3 py-8 text-center text-sm text-muted-foreground">
              {searchQuery ? "No users found" : "No users online"}
            </div>
          ) : (
            filteredUsers.map((contact) => (
              <button
                key={contact.id}
                onClick={() => onSelectUser(contact)}
                data-testid={`button-contact-${contact.id}`}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-md hover-elevate active-elevate-2 transition-colors",
                  selectedUserId === contact.id && "bg-sidebar-accent"
                )}
              >
                <UserAvatar
                  displayName={contact.displayName}
                  avatarColor={contact.avatarColor}
                  status={contact.status}
                  size="sm"
                  showStatus
                />
                <div className="flex-1 min-w-0 text-left">
                  <p className="text-sm font-medium text-sidebar-foreground truncate">{contact.displayName}</p>
                  <p className="text-xs text-muted-foreground truncate">@{contact.username}</p>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>

      <Separator />

      <div className="p-2">
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start"
          onClick={logout}
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
