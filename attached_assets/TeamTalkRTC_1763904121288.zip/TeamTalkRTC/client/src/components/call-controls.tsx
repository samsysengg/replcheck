import { Button } from "@/components/ui/button";
import { Mic, MicOff, Video, VideoOff, PhoneOff, MonitorUp, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

interface CallControlsProps {
  isMuted: boolean;
  isVideoOff: boolean;
  isScreenSharing: boolean;
  onToggleMute: () => void;
  onToggleVideo: () => void;
  onToggleScreenShare: () => void;
  onEndCall: () => void;
  onSettings?: () => void;
}

export function CallControls({
  isMuted,
  isVideoOff,
  isScreenSharing,
  onToggleMute,
  onToggleVideo,
  onToggleScreenShare,
  onEndCall,
  onSettings,
}: CallControlsProps) {
  return (
    <div className="flex items-center justify-center gap-4 p-4 bg-card/50 backdrop-blur-sm">
      <Button
        size="icon"
        variant={isMuted ? "destructive" : "default"}
        onClick={onToggleMute}
        className="w-14 h-14 rounded-full"
        data-testid="button-toggle-mute"
      >
        {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
      </Button>

      <Button
        size="icon"
        variant={isVideoOff ? "destructive" : "default"}
        onClick={onToggleVideo}
        className="w-14 h-14 rounded-full"
        data-testid="button-toggle-video"
      >
        {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
      </Button>

      <Button
        size="icon"
        variant={isScreenSharing ? "default" : "secondary"}
        onClick={onToggleScreenShare}
        className={cn("w-14 h-14 rounded-full", isScreenSharing && "bg-primary")}
        data-testid="button-toggle-screen-share"
      >
        <MonitorUp className="w-5 h-5" />
      </Button>

      <Button
        size="icon"
        variant="destructive"
        onClick={onEndCall}
        className="w-14 h-14 rounded-full"
        data-testid="button-end-call"
      >
        <PhoneOff className="w-5 h-5" />
      </Button>

      {onSettings && (
        <Button
          size="icon"
          variant="ghost"
          onClick={onSettings}
          className="w-10 h-10"
          data-testid="button-call-settings"
        >
          <Settings className="w-5 h-5" />
        </Button>
      )}
    </div>
  );
}
