// Polyfills for browser compatibility with Node.js modules
(window as any).global = window;
(window as any).process = {
  env: { NODE_ENV: import.meta.env.MODE },
  version: '',
  platform: 'browser',
} as any;

// Export to ensure this file is treated as a module
export {};
