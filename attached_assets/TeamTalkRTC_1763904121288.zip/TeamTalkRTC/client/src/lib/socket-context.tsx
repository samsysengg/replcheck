import { createContext, useContext, useEffect, useState, ReactNode, useRef } from "react";
import { io, Socket } from "socket.io-client";
import type { Message, OnlineUser, TypingIndicator, CallSignal } from "@shared/schema";

interface SocketContextType {
  socket: Socket | null;
  isConnected: boolean;
  sendMessage: (roomId: string, content: string) => void;
  joinRoom: (roomId: string) => void;
  leaveRoom: (roomId: string) => void;
  setTyping: (roomId: string, isTyping: boolean) => void;
  sendCallSignal: (signal: CallSignal) => void;
}

const SocketContext = createContext<SocketContextType | null>(null);

export function SocketProvider({ children, userId }: { children: ReactNode; userId?: string }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!userId) return;

    const newSocket = io({
      withCredentials: true,
    });

    newSocket.on("connect", () => {
      setIsConnected(true);
    });

    newSocket.on("disconnect", () => {
      setIsConnected(false);
    });

    socketRef.current = newSocket;
    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [userId]);

  const sendMessage = (roomId: string, content: string) => {
    if (socket) {
      socket.emit("message", { roomId, content });
    }
  };

  const joinRoom = (roomId: string) => {
    if (socket) {
      socket.emit("join-room", roomId);
    }
  };

  const leaveRoom = (roomId: string) => {
    if (socket) {
      socket.emit("leave-room", roomId);
    }
  };

  const setTyping = (roomId: string, isTyping: boolean) => {
    if (socket) {
      socket.emit("typing", { roomId, isTyping });
    }
  };

  const sendCallSignal = (signal: CallSignal) => {
    if (socket) {
      socket.emit("call-signal", signal);
    }
  };

  return (
    <SocketContext.Provider
      value={{ socket, isConnected, sendMessage, joinRoom, leaveRoom, setTyping, sendCallSignal }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error("useSocket must be used within SocketProvider");
  }
  return context;
}
