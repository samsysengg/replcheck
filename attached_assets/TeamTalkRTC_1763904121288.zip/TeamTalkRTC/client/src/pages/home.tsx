import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/auth-context";
import { useSocket } from "@/lib/socket-context";
import { SidebarNav } from "@/components/sidebar-nav";
import { ChatInterface } from "@/components/chat-interface";
import { VideoGrid } from "@/components/video-grid";
import { CallControls } from "@/components/call-controls";
import { IncomingCallModal } from "@/components/incoming-call-modal";
import { useToast } from "@/hooks/use-toast";
import SimplePeer from "simple-peer";
import type { OnlineUser, CallSignal } from "@shared/schema";

export default function HomePage() {
  const { user, onlineUsers, updateOnlineUsers } = useAuth();
  const { socket } = useSocket();
  const { toast } = useToast();

  const [selectedUser, setSelectedUser] = useState<OnlineUser | null>(null);
  const [activeTab, setActiveTab] = useState<"chat" | "calls">("chat");
  const [inCall, setInCall] = useState(false);
  const [callType, setCallType] = useState<"video" | "audio">("video");
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [incomingCall, setIncomingCall] = useState<{ from: string; fromName: string; fromAvatar: string; type: "video" | "audio" } | null>(null);

  const peerRef = useRef<SimplePeer.Instance | null>(null);
  const callRoomRef = useRef<string>("");
  
  const getRoomId = (userId1: string, userId2: string) => {
    return [userId1, userId2].sort().join("---");
  };

  useEffect(() => {
    if (socket) {
      socket.on("users-online", (users: OnlineUser[]) => {
        updateOnlineUsers(users);
      });

      socket.on("user-status-change", ({ userId, status }: { userId: string; status: string }) => {
        updateOnlineUsers(onlineUsers.map(u => u.id === userId ? { ...u, status } as OnlineUser : u));
      });

      socket.on("call-signal", handleCallSignal);

      return () => {
        socket.off("users-online");
        socket.off("user-status-change");
        socket.off("call-signal");
      };
    }
  }, [socket, onlineUsers, updateOnlineUsers]);

  const handleCallSignal = async (signal: CallSignal) => {
    if (signal.type === "offer" && signal.from && signal.signal) {
      const caller = onlineUsers.find(u => u.id === signal.from);
      if (caller) {
        setIncomingCall({
          from: signal.from,
          fromName: caller.displayName,
          fromAvatar: caller.avatarColor,
          type: signal.signal.type === "video" ? "video" : "audio",
        });
      }
    } else if (signal.type === "answer" && signal.signal && peerRef.current) {
      peerRef.current.signal(signal.signal);
    } else if (signal.type === "ice-candidate" && signal.signal && peerRef.current) {
      peerRef.current.signal(signal.signal);
    }
  };

  const startCall = async (type: "video" | "audio") => {
    if (!selectedUser || !socket || !user) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: type === "video",
        audio: true,
      });

      setLocalStream(stream);
      setCallType(type);
      setInCall(true);

      const peer = new SimplePeer({
        initiator: true,
        trickle: true,
        stream,
      });

      peer.on("signal", (data) => {
        socket.emit("call-signal", {
          type: "offer",
          to: selectedUser.id,
          from: user.id,
          signal: { ...data, type },
        });
      });

      peer.on("stream", (stream) => {
        setRemoteStream(stream);
      });

      peer.on("error", (err) => {
        console.error("Peer error:", err);
        toast({
          title: "Call error",
          description: "Failed to establish connection",
          variant: "destructive",
        });
        endCall();
      });

      peerRef.current = peer;
    } catch (error) {
      toast({
        title: "Permission denied",
        description: "Unable to access camera or microphone",
        variant: "destructive",
      });
    }
  };

  const acceptCall = async () => {
    if (!incomingCall || !socket || !user) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: incomingCall.type === "video",
        audio: true,
      });

      setLocalStream(stream);
      setCallType(incomingCall.type);
      setInCall(true);

      const peer = new SimplePeer({
        initiator: false,
        trickle: true,
        stream,
      });

      peer.on("signal", (data) => {
        socket.emit("call-signal", {
          type: "answer",
          to: incomingCall.from,
          from: user.id,
          signal: data,
        });
      });

      peer.on("stream", (stream) => {
        setRemoteStream(stream);
      });

      peer.on("error", (err) => {
        console.error("Peer error:", err);
        endCall();
      });

      peerRef.current = peer;
      setIncomingCall(null);
    } catch (error) {
      toast({
        title: "Permission denied",
        description: "Unable to access camera or microphone",
        variant: "destructive",
      });
      setIncomingCall(null);
    }
  };

  const declineCall = () => {
    setIncomingCall(null);
    toast({
      title: "Call declined",
      description: "You declined the call",
    });
  };

  const endCall = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    if (remoteStream) {
      remoteStream.getTracks().forEach(track => track.stop());
      setRemoteStream(null);
    }
    if (peerRef.current) {
      peerRef.current.destroy();
      peerRef.current = null;
    }
    setInCall(false);
    setIsMuted(false);
    setIsVideoOff(false);
    setIsScreenSharing(false);
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: callType === "video",
        audio: true,
      });
      setLocalStream(stream);
      if (peerRef.current) {
        peerRef.current.replaceTrack(
          localStream!.getVideoTracks()[0],
          stream.getVideoTracks()[0],
          localStream!
        );
      }
      setIsScreenSharing(false);
    } else {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenTrack = screenStream.getVideoTracks()[0];

        if (peerRef.current && localStream) {
          peerRef.current.replaceTrack(
            localStream.getVideoTracks()[0],
            screenTrack,
            localStream
          );
        }

        screenTrack.onended = () => {
          toggleScreenShare();
        };

        setIsScreenSharing(true);
      } catch (error) {
        toast({
          title: "Screen share failed",
          description: "Unable to share screen",
          variant: "destructive",
        });
      }
    }
  };

  const participants = [
    ...(localStream
      ? [{
          id: "local",
          name: user?.displayName || "You",
          avatarColor: user?.avatarColor || "#3b82f6",
          stream: localStream,
          isMuted,
          isVideoOff,
        }]
      : []),
    ...(remoteStream && selectedUser
      ? [{
          id: selectedUser.id,
          name: selectedUser.displayName,
          avatarColor: selectedUser.avatarColor,
          stream: remoteStream,
        }]
      : []),
  ];

  if (!user) return null;

  return (
    <div className="flex h-screen w-full overflow-hidden">
      <div className="w-80 shrink-0">
        <SidebarNav
          onlineUsers={onlineUsers}
          onSelectUser={setSelectedUser}
          selectedUserId={selectedUser?.id}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
      </div>

      <div className="flex-1 flex flex-col">
        {!selectedUser ? (
          <div className="flex-1 flex items-center justify-center bg-background">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Select a conversation</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Choose a contact from the sidebar to start chatting or make a call
              </p>
            </div>
          </div>
        ) : inCall ? (
          <div className="flex-1 flex flex-col bg-black">
            <div className="flex-1">
              <VideoGrid participants={participants} localStream={localStream || undefined} />
            </div>
            <CallControls
              isMuted={isMuted}
              isVideoOff={isVideoOff}
              isScreenSharing={isScreenSharing}
              onToggleMute={toggleMute}
              onToggleVideo={toggleVideo}
              onToggleScreenShare={toggleScreenShare}
              onEndCall={endCall}
            />
          </div>
        ) : (
          <ChatInterface selectedUser={selectedUser} onStartCall={startCall} />
        )}
      </div>

      <IncomingCallModal
        open={!!incomingCall}
        callerName={incomingCall?.fromName || ""}
        callerAvatar={incomingCall?.fromAvatar || ""}
        callType={incomingCall?.type || "video"}
        onAccept={acceptCall}
        onDecline={declineCall}
      />
    </div>
  );
}
