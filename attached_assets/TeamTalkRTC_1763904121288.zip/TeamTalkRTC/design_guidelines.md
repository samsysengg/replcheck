# Design Guidelines: Teams-Like Communication Platform

## Design Approach
**Selected Approach:** Design System (Fluent Design) with inspiration from Microsoft Teams and Slack

**Justification:** This is a utility-focused productivity application where efficiency, learnability, and information density are paramount. Users need to quickly navigate between chats, manage calls, and access features without visual friction.

**Key Design Principles:**
- Clarity over decoration - every element serves a functional purpose
- Consistent spatial rhythm for predictable interaction patterns
- Dense information hierarchy without overwhelming users
- Instant visual feedback for real-time interactions

---

## Typography

**Font Families:**
- Primary: Inter (400, 500, 600) via Google Fonts CDN
- Monospace: JetBrains Mono (400) for timestamps, code snippets

**Hierarchy:**
- Page/Section Headers: text-2xl font-semibold
- Chat Messages/User Names: text-base font-medium
- Message Content: text-sm font-normal
- Timestamps/Meta: text-xs font-normal
- Button Labels: text-sm font-medium
- Navigation Items: text-sm font-medium

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8 (p-2, m-4, gap-6, h-8, etc.)

**Application Shell:**
- Three-column layout for main interface:
  - Left Sidebar (w-64): Navigation, contacts, channels
  - Middle Panel (flex-1): Active chat/meeting view
  - Right Sidebar (w-80, collapsible): Participant list, details, files

**Grid Usage:**
- Video meeting grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Contact list: Single column with consistent item height (h-16)
- Message threads: Single column, full-width with max-w-4xl for readability

**Consistent Padding:**
- Sidebar sections: p-4
- Chat messages: px-4 py-2
- Modal/Dialog: p-6
- Button groups: gap-2
- List items: gap-4

---

## Component Library

### Navigation & Layout
**Left Sidebar:**
- Fixed width (w-64), full height, divided into sections
- Top: User profile card (avatar + name + status, h-20)
- Middle: Navigation tabs (Chat, Teams, Calls, Files) - each h-12
- Bottom: Contact list with scrollable area, search input at top (h-10)
- Each contact item: h-16 with avatar (w-10 h-10), name, status indicator

**Top Bar (Meeting/Chat Header):**
- h-16, spans full width
- Left: Contact/channel name (text-lg font-semibold)
- Center: Active participants count, meeting timer
- Right: Action buttons (video, audio, screen share, settings) - icon buttons w-10 h-10

### Chat Interface
**Message List:**
- Scrollable container with reverse flex direction
- Message bubbles: max-w-2xl, rounded-lg, p-3
- Sender messages: ml-auto (right-aligned)
- Received messages: mr-auto (left-aligned)
- Avatar: w-8 h-8 (for received messages only)
- Timestamps: text-xs, mt-1

**Message Input:**
- Fixed bottom container, h-20
- Text input: min-h-12, rounded-lg, px-4 py-3
- Action buttons row: h-10, gap-2 (attach, emoji, formatting)

### Video/Call Interface
**Video Grid:**
- Responsive grid adapts to participant count
- Each video tile: aspect-video, rounded-lg, relative container
- Participant name overlay: absolute bottom-2 left-2, px-2 py-1, text-xs
- Muted indicator: absolute top-2 right-2, icon-only

**Call Controls Bar:**
- Fixed bottom, h-20, centered button group
- Primary controls: w-14 h-14 rounded-full (Mute, Video, Screen Share)
- End call button: w-14 h-14 rounded-full (distinctive treatment)
- Device settings: w-10 h-10 (positioned at far right)

**Active Speaker View:**
- Main video: Fills available space (flex-1)
- Participant thumbnails: Fixed bottom row, h-24, gap-2, scrollable horizontally

### Forms & Inputs
**Search Bars:**
- h-10, rounded-lg, px-3
- Icon prefix (w-5 h-5)
- Clear button suffix when active

**Status Selector:**
- Dropdown menu, max-h-64
- Each status option: h-12, px-4
- Status indicator dot: w-3 h-3

**Settings Panels:**
- Modal overlay with centered card: max-w-2xl, p-6
- Section headers: text-lg font-semibold, mb-4
- Form groups: space-y-4
- Toggle switches: w-11 h-6

### Indicators & Feedback
**Presence Indicators:**
- Online: Filled circle, w-3 h-3
- Away: Outlined circle
- Offline: Hollow circle
- Positioning: absolute -bottom-0.5 -right-0.5 relative to avatar

**Typing Indicators:**
- Animated dots, h-4, displayed in chat footer
- "User is typing..." text-xs

**Connection Quality:**
- Icon-based (bars), positioned top-right of video tiles
- w-4 h-4, three states (good, medium, poor)

**Unread Badges:**
- Absolute positioned on navigation items
- w-5 h-5, rounded-full, text-xs, centered text

### Modals & Overlays
**Incoming Call Modal:**
- Centered overlay, w-96, p-6, rounded-xl
- Caller info: Avatar (w-20 h-20), name (text-xl)
- Action buttons: h-12, full width, gap-3

**Meeting Info Panel:**
- Slide-in from right, w-80, full height, p-4
- Scrollable content with sections (Participants, Chat, Details)
- Section headers: h-10, text-sm font-semibold

---

## Icons
**Library:** Heroicons (via CDN)
- Navigation: outline style, w-6 h-6
- Actions/Controls: solid style, w-5 h-5
- Status indicators: mini style, w-4 h-4

---

## Animations
**Minimal, Purposeful Only:**
- Message send: Subtle slide-in (150ms)
- Modal appearance: Fade-in (200ms)
- Status changes: No animation, instant update
- Video tile resize: Smooth transition (300ms)
- No hover effects on functional elements - focus on clarity

---

## Accessibility
- Focus states: Consistent 2px outline with offset
- All interactive elements: Minimum h-10 touch target
- Keyboard navigation: Tab order follows visual hierarchy
- Screen reader labels: aria-label on all icon-only buttons
- Color-independent status indicators (icons + text)