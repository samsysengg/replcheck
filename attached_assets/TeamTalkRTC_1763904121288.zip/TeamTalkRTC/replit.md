# TeamConnect - Real-time Team Collaboration Platform

## Overview
A production-ready Teams-like communication platform built with React, Express, Socket.io, and WebRTC. Features real-time chat, 1-on-1 video/audio calls, and team meetings.

## Project Structure

### Frontend (`client/`)
- **React SPA** with TypeScript
- **State Management**: React Context (Auth, Socket, Theme)
- **UI Library**: Shadcn UI + Tailwind CSS
- **Real-time**: Socket.io-client
- **WebRTC**: Simple-peer for video/audio calls
- **Routing**: Wouter

### Backend (`server/`)
- **Express.js** with TypeScript
- **Real-time**: Socket.io server
- **Storage**: In-memory storage (MemStorage)
- **Sessions**: Express-session with MemoryStore

### Shared (`shared/`)
- Type-safe schemas and interfaces shared between frontend and backend

## Key Features

### 1. Real-time Chat
- 1-on-1 messaging with typing indicators
- Message history persistence
- Read receipts
- Real-time message delivery via Socket.io

### 2. Video & Audio Calls
- WebRTC-based peer-to-peer connections
- Video calls with camera on/off toggle
- Audio calls with mute/unmute controls
- Screen sharing capability
- Incoming call notifications with accept/decline

### 3. User Presence
- Online/offline status indicators
- Real-time status updates
- User directory with search

### 4. UI/UX Excellence
- Microsoft Teams-inspired design
- Dark/light theme support
- Responsive layout (3-column design)
- Beautiful loading and empty states
- Smooth animations and transitions
- Accessibility-first approach

## Technical Architecture

### Real-time Communication Flow
```
Client → Socket.io Client → Socket.io Server → Broadcast to Room/Users
```

### WebRTC Signaling Flow
```
Caller → offer signal → Socket.io → Callee
Callee → answer signal → Socket.io → Caller
Both → ICE candidates → Socket.io → Peer
Direct peer-to-peer media connection established
```

### Data Models
- **User**: id, username, password, displayName, status, avatarColor
- **Message**: id, roomId, senderId, content, timestamp, read
- **ChatRoom**: id, name, isGroup, participants, lastMessage, lastMessageTime
- **CallSignal**: type, from, to, roomId, signal (WebRTC signaling)
- **OnlineUser**: id, username, displayName, status, avatarColor

## Setup & Development

### Prerequisites
- Node.js 20+
- npm

### Installation
```bash
npm install
```

### Running the Application
```bash
npm run dev
```
Starts both frontend (Vite) and backend (Express) servers on the same port.

### Environment Variables
- `SESSION_SECRET`: Used for session encryption (already configured)

## User Preferences
- Clean, professional UI following Microsoft Teams/Fluent Design principles
- Inter font family for consistency
- Production-ready code with proper error handling
- Real-time features without polling
- Peer-to-peer video calls for better performance

## Recent Changes
- [2025-01-23] Initial implementation with complete chat, video call, and presence features
- Schema-first development approach for type safety
- All frontend components built with exceptional attention to detail
- Socket.io server configured for real-time messaging and signaling
- WebRTC integration for video/audio calls
- In-memory storage for rapid prototyping

## Architecture Decisions
1. **In-memory storage**: Fast prototyping, easy testing, suitable for demo/MVP
2. **Simple-peer**: Simplified WebRTC implementation over native APIs
3. **Socket.io**: Battle-tested real-time library with fallbacks
4. **Shadcn UI**: Accessible, customizable component library
5. **Schema-first**: Shared types between frontend/backend for type safety

## Next Steps (Future Enhancements)
- PostgreSQL database for persistent storage
- Multi-participant meetings (>2 participants)
- File sharing and media attachments
- Meeting recording functionality
- End-to-end encryption
- Calendar integration
- Mobile PWA optimization
- Background blur and virtual backgrounds
