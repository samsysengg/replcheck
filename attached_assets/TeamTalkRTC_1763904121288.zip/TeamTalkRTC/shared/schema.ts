import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  status: text("status", { enum: ["online", "away", "busy", "offline"] }).notNull().default("offline"),
  avatarColor: text("avatar_color").notNull().default("#3b82f6"),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull(),
  senderId: varchar("sender_id").notNull(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  read: boolean("read").notNull().default(false),
});

export const chatRooms = pgTable("chat_rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name"),
  isGroup: boolean("is_group").notNull().default(false),
  participants: text("participants").array().notNull(),
  lastMessage: text("last_message"),
  lastMessageTime: timestamp("last_message_time"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, status: true, avatarColor: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true, read: true });
export const insertChatRoomSchema = createInsertSchema(chatRooms).omit({ id: true, lastMessage: true, lastMessageTime: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertChatRoom = z.infer<typeof insertChatRoomSchema>;
export type ChatRoom = typeof chatRooms.$inferSelect;

export type UserStatus = "online" | "away" | "busy" | "offline";

export interface CallSignal {
  type: "offer" | "answer" | "ice-candidate" | "join" | "leave" | "user-joined" | "user-left";
  from: string;
  to?: string;
  roomId?: string;
  signal?: any;
  userId?: string;
  userName?: string;
}

export interface TypingIndicator {
  roomId: string;
  userId: string;
  userName: string;
  isTyping: boolean;
}

export interface OnlineUser {
  id: string;
  username: string;
  displayName: string;
  status: UserStatus;
  avatarColor: string;
}
